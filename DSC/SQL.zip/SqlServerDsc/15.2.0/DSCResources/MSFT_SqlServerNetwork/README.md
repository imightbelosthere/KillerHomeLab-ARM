# DEPRECATION NOTICE

The `SqlServerNetwork` DSC resource is **DEPRECATED**. The resource
is replaced by the resources `SqlServerProtocol` and `SqlServerProtocolTcpIp`.

The documentation, examples, unit test, and integration tests have been
removed. This resource will be removed in a future release.
