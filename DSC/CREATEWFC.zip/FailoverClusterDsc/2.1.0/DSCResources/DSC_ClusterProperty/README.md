# Description

Configures cluster properties on a failover cluster.

## Requirements

* Target machine must be running Windows Server 2008 R2 or later.
