﻿configuration W11BASESTIG
{

   param
   (
        [String]$W11BASESTIGMOFSASUrl
    )

    Import-DscResource -Module xPSDesiredStateConfiguration # Used for xRemoteFile

    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = "StopConfiguration"
            ConfigurationMode = "ApplyOnly"
        }

        Script EnableTls12
        {
            SetScript =
            {
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

            }
            GetScript =  { @{} }
            TestScript = { $false}
        }

        Script InstallPowerSTIG
        {
            SetScript =
            {
                Set-Service -Name "WinRM" -StartupType Automatic
                Start-Service -Name "WinRM"
                $Interface=Get-NetAdapter|Where-Object Name -Like "Ethernet*"|Select-Object -First 1
                $InterfaceAlias=$($Interface.Name)
                Set-NetConnectionProfile -InterfaceAlias $InterfaceAlias -NetworkCategory Private
                Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb -Value 8192
                Enable-PSRemoting –Force

                Install-PackageProvider -Name NuGet -Force
                Install-Module PowerSTIG -Force
                Import-Module PowerSTIG
            }
            GetScript =  { @{} }
            TestScript = { $false}
            DependsOn = '[Script]EnableTls12'
        }

        File STIGArtifacts
        {
            Type = 'Directory'
            DestinationPath = 'C:\W11BASESTIG'
            Ensure = "Present"
            DependsOn = '[Script]InstallPowerSTIG'
        }

        File CopyXML
        {
            Ensure = "Present"
            Type = "File"
            SourcePath = "C:\Program Files\WindowsPowerShell\Modules\PowerSTIG\4.16.0\StigData\Processed\WindowsClient-11-1.2.org.default.xml"
            DestinationPath = "C:\W11BASESTIG\WindowsClient-11-1.2.org.1.0.xml"
            DependsOn = "[File]STIGArtifacts"
        }

        xRemoteFile W11BASESTIGMOF
        {
            DestinationPath = "C:\W11BASESTIG\W11BASESTIG-MOF.ps1"
            Uri             = $W11BASESTIGMOFSASUrl
            UserAgent       = "[Microsoft.PowerShell.Commands.PSUserAgent]::InternetExplorer"
            DependsOn = '[File]CopyXML'
        }

        Script APPLYW11BASESTIG
        {
            SetScript =
            {
                Start-DscConfiguration -Path C:\W11BASESTIG -Verbose -Wait
            }
            GetScript =  { @{} }
            TestScript = { $false}
            DependsOn = '[xRemoteFile]W11BASESTIGMOF'
        }
    }
}