# Description

The xDnsServerPrimaryZone DSC resource manages a standalone file-backed Primary zone on a given Domain Name System (DNS) server.
