# Description

This resource can be used to install an ADCS Certificate Enrollment Policy Web
Service on the server after the feature has been installed on the server.
Using this DSC Resource to configure an ADCS Certificate Authority assumes that
the `ADCS-Enroll-Web-Pol` feature has already been installed.
